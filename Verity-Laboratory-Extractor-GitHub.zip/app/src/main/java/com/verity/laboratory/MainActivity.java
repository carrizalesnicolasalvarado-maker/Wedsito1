package com.verity.laboratory;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebSettings;
import android.webkit.WebViewClient;
import android.webkit.JavascriptInterface;
import android.content.Intent;
import android.content.ContentValues;
import android.net.Uri;
import android.provider.MediaStore;
import android.os.Environment;
import java.io.OutputStream;
import java.util.concurrent.ConcurrentHashMap;
import java.util.UUID;
import android.util.Base64;

public class MainActivity extends Activity {
    private WebView web;
    private final ConcurrentHashMap<String, Uri> pending = new ConcurrentHashMap<>();

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        web = new WebView(this);
        setContentView(web);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setMediaPlaybackRequiresUserGesture(true);
        web.setWebViewClient(new WebViewClient());
        web.addJavascriptInterface(new Bridge(), "AndroidBridge");
        web.loadUrl("file:///android_asset/index.html");
    }

    public class Bridge {
        @JavascriptInterface public String beginDownload(String name, String mime) {
            try {
                String safe = name == null ? "audio.mp3" : name.replaceAll("[\\\\/:*?\\\"<>|]", "_");
                ContentValues v = new ContentValues();
                v.put(MediaStore.Downloads.DISPLAY_NAME, safe);
                v.put(MediaStore.Downloads.MIME_TYPE, mime == null ? "audio/mpeg" : mime);
                v.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Verity");
                Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
                if (uri == null) return "";
                String id = UUID.randomUUID().toString();
                pending.put(id, uri);
                return id;
            } catch (Exception e) { return ""; }
        }
        @JavascriptInterface public boolean appendDownloadChunk(String id, String data) {
            try {
                Uri uri = pending.get(id); if (uri == null) return false;
                byte[] bytes = Base64.decode(data, Base64.DEFAULT);
                try (OutputStream out = getContentResolver().openOutputStream(uri, "wa")) { if (out == null) return false; out.write(bytes); }
                return true;
            } catch (Exception e) { return false; }
        }
        @JavascriptInterface public boolean finishDownload(String id) { return pending.remove(id) != null; }
        @JavascriptInterface public void cancelDownload(String id) {
            Uri uri = pending.remove(id);
            if (uri != null) try { getContentResolver().delete(uri, null, null); } catch (Exception ignored) {}
        }
        @JavascriptInterface public void shareText(String text) {
            runOnUiThread(() -> {
                Intent i = new Intent(Intent.ACTION_SEND);
                i.setType("text/plain"); i.putExtra(Intent.EXTRA_TEXT, text);
                startActivity(Intent.createChooser(i, "Compartir Verity"));
            });
        }
    }

    @Override public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack(); else super.onBackPressed();
    }
}
