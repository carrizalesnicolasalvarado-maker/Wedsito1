# Verity Laboratory Extractor

Android WebView app project. The HTML can also be tested directly in a modern browser.

## Build APK with GitHub
1. Create a GitHub repository and upload the contents of this ZIP (not the ZIP file itself).
2. Open **Actions** and run **Build Verity APK**, or push to `main`.
3. Open the completed workflow run and download the `VerityLaboratoryExtractor-debug` artifact.
4. Extract the artifact ZIP to get `app-debug.apk`.

## Storage behavior
- The $0.00 button is a local unlock only; it does not process a payment.
- Folders and MP3 files are stored in IndexedDB inside the app's WebView data.
- Data remains after closing/reopening the app and restarting the phone, provided app data is not cleared and the app is not uninstalled.
- When storage is unlocked and a folder exists, completed video-to-audio conversions are encoded to MP3 and saved automatically to the selected folder.
- The Storage screen lets you select a folder and export saved MP3 files.

## Important
This project is a clean WebView wrapper around the HTML recovered from the APK you supplied. It is not the original Android Studio source project. Test the generated APK on your phone before sharing it.
